﻿var created_disruption_id = context.variableManager.getValue("created_disruption_id");
var created_impact_id = context.variableManager.getValue("created_impact_id");
var lock = new java.util.concurrent.locks.ReentrantLock();

lock.lock();
var writer = new java.io.FileWriter("/tmp/disruptions.csv", true);
writer.write(created_disruption_id+';'+created_impact_id);
writer.write("\n");
writer.close();
lock.unlock();
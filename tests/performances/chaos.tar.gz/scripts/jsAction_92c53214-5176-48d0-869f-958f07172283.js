﻿var properties_file = context.variableManager.getValue("properties_file");
var created_property_id = context.variableManager.getValue("created_property_id");
var lock = new java.util.concurrent.locks.ReentrantLock();

lock.lock();
var writer = new java.io.FileWriter(properties_file, true);
writer.write(created_property_id);
writer.write("\n");
writer.close();
 
lock.unlock();
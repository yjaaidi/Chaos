﻿var causes_file = context.variableManager.getValue("causes_file");
var created_cause_id = context.variableManager.getValue("created_cause_id");
var lock = new java.util.concurrent.locks.ReentrantLock();

lock.lock();
var writer = new java.io.FileWriter(causes_file, true);
writer.write(created_cause_id);
writer.write("\n");
writer.close();
 
lock.unlock();
﻿var created_channel_id = context.variableManager.getValue("created_channel_id");
var lock = new java.util.concurrent.locks.ReentrantLock();

lock.lock();
var writer = new java.io.FileWriter("/tmp/channels.csv", true);
writer.write(created_channel_id);
writer.write("\n");
writer.close();
 
lock.unlock();